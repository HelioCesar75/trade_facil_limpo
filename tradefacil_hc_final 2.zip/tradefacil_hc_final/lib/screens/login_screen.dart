import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'main_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final user = TextEditingController();
  final pass = TextEditingController();
  final auth = AuthService();
  String error = "";

  void login() async {
    final ok = await auth.login(user.text.trim(), pass.text);
    if (ok) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen()));
    } else {
      setState(() => error = "Usuário ou senha inválidos.");
    }
  }

  void register() async {
    final ok = await auth.register(user.text.trim(), pass.text);
    if (ok) setState(() => error = "Conta criada! Faça login.");
    else setState(() => error = "Erro ao criar conta.");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade700,
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
          width: 340,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text("Trade Fácil HC", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(controller: user, decoration: const InputDecoration(labelText: "Usuário")),
            const SizedBox(height: 8),
            TextField(controller: pass, decoration: const InputDecoration(labelText: "Senha"), obscureText: true),
            const SizedBox(height: 12),
            if (error.isNotEmpty) Text(error, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: ElevatedButton(onPressed: login, child: const Text("Entrar"))),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: register, child: const Text("Criar"))
            ])
          ]),
        ),
      ),
    );
  }
}