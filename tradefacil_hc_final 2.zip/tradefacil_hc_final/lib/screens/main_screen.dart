import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  File? image;
  final picker = ImagePicker();
  final ma9 = TextEditingController();
  final ma20 = TextEditingController();
  final ma50 = TextEditingController();
  final macdH = TextEditingController();
  final macdS = TextEditingController();
  String result = "";

  void pickImage() async {
    final XFile? img = await picker.pickImage(source: ImageSource.gallery);
    if (img != null) setState(() => image = File(img.path));
  }

  void analyze() {
    double m9 = double.tryParse(ma9.text) ?? 0;
    double m20 = double.tryParse(ma20.text) ?? 0;
    double m50 = double.tryParse(ma50.text) ?? 0;
    double h = double.tryParse(macdH.text) ?? 0;
    double s = double.tryParse(macdS.text) ?? 0;

    if (m9 > m20 && m20 > m50 && h > s) result = "Tendência de ALTA";
    else if (m9 < m20 && m20 < m50 && h < s) result = "Tendência de BAIXA";
    else result = "Neutro / Indefinido";

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Trade Fácil HC")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          ElevatedButton(onPressed: pickImage, child: const Text("Enviar Print")),
          if (image != null) Image.file(image!, height: 180),
          const SizedBox(height: 12),
          const Text("Indicadores", style: TextStyle(fontSize: 18)),
          TextField(controller: ma9, decoration: const InputDecoration(labelText: "MM9")),
          TextField(controller: ma20, decoration: const InputDecoration(labelText: "MM20")),
          TextField(controller: ma50, decoration: const InputDecoration(labelText: "MM50")),
          TextField(controller: macdH, decoration: const InputDecoration(labelText: "MACD Hist")),
          TextField(controller: macdS, decoration: const InputDecoration(labelText: "MACD Signal")),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: analyze, child: const Text("Analisar")),
          if (result.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(result, style: const TextStyle(fontSize: 18, color: Colors.blue)))
        ]),
      ),
    );
  }
}